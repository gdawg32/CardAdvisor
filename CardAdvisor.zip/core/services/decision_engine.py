import logging
import math
from typing import Any, Dict, List, Optional

from django.db.models import Prefetch

from core.models import CreditCard, RewardCategory

logger = logging.getLogger(__name__)

# Configuration constants 
LOUNGE_VALUE_PER_VISIT = 800.0  # assumed value
DEFAULT_WEIGHTS = {"cashback": 0.6, "lounge": 0.2, "fee": 0.15, "forex": 0.05}
DEFAULT_ALPHA = 0.75  
TIE_EPSILON = 1.0  
SENSITIVITY_SCENARIOS = {
    "online_plus_10pct": {"online": 1.10},
    "travel_plus_50pct": {"travel": 1.50},
    "foreign_x2": {"monthly_foreign": 2.0},
}


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if math.isnan(v) or v < 0:
            return default
        return v
    except Exception:
        return default


def _min_max_normalize(value: float, min_v: float, max_v: float) -> float:
    if max_v == min_v:
        return 1.0
    return (value - min_v) / (max_v - min_v)


def _invert_normalized(value: float) -> float:
    return 1.0 - value


# ----------------- reward rule computation -----------------


def compute_monthly_reward_for_rule(
    user_monthly_spend: float,
    reward_rate: float,
    cap_type: str,
    monthly_cap_amount: Optional[float],
) -> float:
    """
    Compute monthly reward (₹) for a single RewardCategory rule.
    cap_type: "none" | "spend" | "cashback"
    monthly_cap_amount semantics:
      - None: no cap
      - spend: interpreted as ₹ spend cap
      - cashback: interpreted as ₹ cashback cap
    """
    user_monthly_spend = _safe_float(user_monthly_spend, 0.0)
    reward_rate = _safe_float(reward_rate, 0.0)
    if user_monthly_spend <= 0 or reward_rate <= 0:
        return 0.0

    if cap_type is None or cap_type == "none" or monthly_cap_amount is None:
        return user_monthly_spend * reward_rate

    cap_amount = _safe_float(monthly_cap_amount, 0.0)
    if cap_type == "spend":
        eligible_spend = min(user_monthly_spend, cap_amount)
        return eligible_spend * reward_rate

    if cap_type == "cashback":
        raw_reward = user_monthly_spend * reward_rate
        return min(raw_reward, cap_amount)

    return user_monthly_spend * reward_rate


def compute_break_even_monthly_extra(
    effective_fee: float,
    user_monthly_spend_for_category: float,
    reward_rate: float,
    cap_type: str,
    monthly_cap_amount: Optional[float],
) -> Optional[float]:
    """
    Simplified break-even: monthly extra spend in that category required to recover effective_fee (annual).
    Returns None if not computable.
    """
    effective_fee = _safe_float(effective_fee, 0.0)
    user_monthly_spend_for_category = _safe_float(user_monthly_spend_for_category, 0.0)
    reward_rate = _safe_float(reward_rate, 0.0)

    if effective_fee <= 0:
        return 0.0
    if reward_rate <= 0:
        return None

    # No cap
    if cap_type in (None, "none"):
        return effective_fee / (12.0 * reward_rate)

    cap_amount = _safe_float(monthly_cap_amount, 0.0)

    if cap_type == "spend":
        remaining_eligible = max(0.0, cap_amount - user_monthly_spend_for_category)
        reward_from_remaining = remaining_eligible * reward_rate * 12.0
        if reward_from_remaining >= effective_fee:
            return effective_fee / (12.0 * reward_rate)
        # cannot recover beyond cap using this category alone
        return remaining_eligible

    if cap_type == "cashback":
        current_monthly_raw = user_monthly_spend_for_category * reward_rate
        remaining_cashback_monthly = max(0.0, cap_amount - current_monthly_raw)
        if remaining_cashback_monthly <= 0:
            return 0.0
        # if remaining annual cashback >= fee, compute needed extra monthly spend
        if remaining_cashback_monthly * 12.0 >= effective_fee:
            needed_monthly_cashback = effective_fee / 12.0
            return needed_monthly_cashback / reward_rate
        # otherwise return amount required to exhaust remaining cashback
        return remaining_cashback_monthly / reward_rate

    return None


# ----------------- normalization & composite -----------------


def normalize_metrics_for_cards(cards_metrics: List[Dict], include_net_value: bool = True) -> List[Dict]:
    cashback_vals = [c["total_rewards"] for c in cards_metrics]
    lounge_vals = [c["lounge_value"] for c in cards_metrics]
    fee_vals = [c["effective_fee"] for c in cards_metrics]
    forex_vals = [c["forex_cost"] for c in cards_metrics]
    net_vals = [c["net_value"] for c in cards_metrics] if include_net_value else None

    def mm(arr):
        if not arr:
            return (0.0, 0.0)
        return (min(arr), max(arr))

    cb_min, cb_max = mm(cashback_vals)
    lg_min, lg_max = mm(lounge_vals)
    fe_min, fe_max = mm(fee_vals)
    fx_min, fx_max = mm(forex_vals)
    nv_min, nv_max = mm(net_vals) if net_vals is not None else (0.0, 0.0)

    for c in cards_metrics:
        norm_cb = _min_max_normalize(c["total_rewards"], cb_min, cb_max)
        norm_lg = _min_max_normalize(c["lounge_value"], lg_min, lg_max)
        norm_fee = _min_max_normalize(c["effective_fee"], fe_min, fe_max)
        norm_fee = _invert_normalized(norm_fee)
        norm_fx = _min_max_normalize(c["forex_cost"], fx_min, fx_max)
        norm_fx = _invert_normalized(norm_fx)
        norm_nv = _min_max_normalize(c["net_value"], nv_min, nv_max) if net_vals is not None else 0.0

        c.setdefault("normalized", {})
        c["normalized"].update(
            {
                "cashback": round(norm_cb, 4),
                "lounge": round(norm_lg, 4),
                "fee": round(norm_fee, 4),
                "forex": round(norm_fx, 4),
                "net_value": round(norm_nv, 4),
            }
        )
    return cards_metrics


def compute_composite_scores(cards_metrics: List[Dict], weights: Dict[str, float]) -> List[Dict]:
    w_total = sum(weights.values()) if weights else 0.0
    if w_total <= 0:
        weights = DEFAULT_WEIGHTS
        w_total = sum(weights.values())
    norm_weights = {k: v / w_total for k, v in weights.items()}

    for c in cards_metrics:
        norm = c.get("normalized", {})
        score = (
            norm_weights.get("cashback", 0.0) * norm.get("cashback", 0.0)
            + norm_weights.get("lounge", 0.0) * norm.get("lounge", 0.0)
            + norm_weights.get("fee", 0.0) * norm.get("fee", 0.0)
            + norm_weights.get("forex", 0.0) * norm.get("forex", 0.0)
        )
        c["composite_score"] = round(score, 4)
    return cards_metrics


# ----------------- main evaluation -----------------


def evaluate_cards(
    user_input: Dict[str, Any],
    weights: Optional[Dict[str, float]] = None,
    alpha: float = DEFAULT_ALPHA,
    lounge_value_per_visit: float = LOUNGE_VALUE_PER_VISIT,
    rank_by: str = "net_value",
    include_ineligible: bool = True,
    run_sensitivity: bool = False,
) -> Dict[str, Any]:
    """
    Robust decision engine with hard forex-support constraint when requested.
    Inputs:
      - user_input: expects keys 'online','fuel','dining','travel','groceries','other',
                    'monthly_foreign','annual_income','fee_tolerance' (optional),
                    'enforce_low_forex' (optional boolean).
      - weights: optional dict for cashback/lounge/fee/forex; if a single weight 'forex'==1.0
                 and others 0.0, engine will treat that as enforce_low_forex if user didn't pass explicit flag.
    Returns payload with ranked_results and ineligible_results and diagnostic fields.
    """
    # --- parse inputs ---
    categories = ["online", "fuel", "dining", "travel", "groceries", "other"]
    monthly_spend = {cat: _safe_float(user_input.get(cat, 0.0)) for cat in categories}
    monthly_foreign = _safe_float(user_input.get("monthly_foreign", 0.0))
    annual_income = _safe_float(user_input.get("annual_income", 0.0))
    fee_tolerance_raw = user_input.get("fee_tolerance", None)
    fee_tolerance = _safe_float(fee_tolerance_raw) if fee_tolerance_raw is not None else None
    enforce_low_forex_flag = bool(user_input.get("enforce_low_forex", False))

    # normalize weights (if provided); if not provided, use default
    if weights:
        # defensive: ensure keys exist
        weights = {k: float(weights.get(k, 0.0)) for k in DEFAULT_WEIGHTS.keys()}
        total_w = sum(weights.values())
        if total_w > 0:
            weights = {k: v / total_w for k, v in weights.items()}
        else:
            weights = DEFAULT_WEIGHTS.copy()
    else:
        weights = DEFAULT_WEIGHTS.copy()

    # If the user toggled forex as the only preference, treat that as a hard constraint
    # (useful when UI provides boolean toggles that normalize to weight=1.0 for single selection)
    forex_as_hard_constraint = False
    if enforce_low_forex_flag:
        forex_as_hard_constraint = True
    else:
        # if forex weight is ~1.0 and others ~0.0, assume user explicitly prioritized forex alone
        if weights.get("forex", 0.0) >= 0.999:
            forex_as_hard_constraint = True

    annual_spend = sum(monthly_spend.values()) * 12.0

    # load cards
    cards_qs = CreditCard.objects.prefetch_related(
        Prefetch("reward_categories", queryset=RewardCategory.objects.all())
    )

    eligible_results: List[Dict[str, Any]] = []
    ineligible_results: List[Dict[str, Any]] = []

    for card in cards_qs:
        card_meta = {"card_id": card.pk, "name": card.name, "issuer": card.issuer}

        # income eligibility
        if annual_income < getattr(card, "min_income_required", 0):
            ineligible_results.append({**card_meta, "eligible": False, "reason_ineligible": "Income below eligibility"})
            continue

        # fee tolerance eligibility
        if fee_tolerance is not None and float(getattr(card, "annual_fee", 0)) > fee_tolerance:
            ineligible_results.append({**card_meta, "eligible": False, "reason_ineligible": "Annual fee exceeds user's tolerance"})
            continue

        # HARD forex constraint: exclude cards that do not support forex when required
        if forex_as_hard_constraint and not bool(getattr(card, "supports_forex", True)):
            ineligible_results.append(
                {
                    **card_meta,
                    "eligible": False,
                    "reason_ineligible": "Does not support international transactions (user prioritized low-forex)",
                }
            )
            continue

        # compute rewards
        monthly_category_rewards: Dict[str, float] = {c: 0.0 for c in categories}
        detailed_rules: List[Dict[str, Any]] = []
        reward_rules = list(card.reward_categories.all())

        for rc in reward_rules:
            cat = getattr(rc, "category", None)
            if cat not in monthly_category_rewards:
                # skip unknown categories
                continue

            monthly_reward = compute_monthly_reward_for_rule(
                user_monthly_spend=monthly_spend.get(cat, 0.0),
                reward_rate=getattr(rc, "reward_rate", 0.0),
                cap_type=getattr(rc, "cap_type", "none") if hasattr(rc, "cap_type") else "none",
                monthly_cap_amount=getattr(rc, "monthly_cap_amount", None) if hasattr(rc, "monthly_cap_amount") else None,
            )
            monthly_category_rewards[cat] += monthly_reward
            detailed_rules.append(
                {
                    "category": cat,
                    "reward_rate": getattr(rc, "reward_rate", 0.0),
                    "cap_type": getattr(rc, "cap_type", "none") if hasattr(rc, "cap_type") else "none",
                    "monthly_cap_amount": getattr(rc, "monthly_cap_amount", None) if hasattr(rc, "monthly_cap_amount") else None,
                    "monthly_reward": round(monthly_reward, 2),
                }
            )

        annual_category_rewards = {k: round(v * 12.0, 2) for k, v in monthly_category_rewards.items()}
        total_annual_rewards = round(sum(annual_category_rewards.values()), 2)

        # lounge valuation
        lounge_value = float(getattr(card, "lounge_visits_per_year", 0)) * float(lounge_value_per_visit)

        # forex cost only if card supports forex (and user has foreign spend)
        if bool(getattr(card, "supports_forex", True)):
            forex_cost = round(monthly_foreign * 12.0 * (float(getattr(card, "forex_markup_percent", 0.0)) / 100.0), 2)
        else:
            forex_cost = 0.0

        # effective fee & waiver (zero-fee cards are considered waived)
        card_fee = float(getattr(card, "annual_fee", 0.0))
        fee_waived = False
        effective_fee = card_fee
        if card_fee == 0:
            fee_waived = True
            effective_fee = 0.0
        else:
            fee_waiver_spend = float(getattr(card, "fee_waiver_spend", 0.0))
            if fee_waiver_spend and annual_spend >= fee_waiver_spend:
                fee_waived = True
                effective_fee = 0.0

        # net monetary value
        net_value = round(total_annual_rewards + lounge_value - effective_fee - forex_cost, 2)

        # top contributing category
        top_cat = None
        if annual_category_rewards:
            top_cat = max(annual_category_rewards.items(), key=lambda kv: kv[1])[0]

        # break-even
        break_even = None
        if top_cat:
            rc_for_top = next((r for r in reward_rules if getattr(r, "category", None) == top_cat), None)
            if rc_for_top:
                break_even = compute_break_even_monthly_extra(
                    effective_fee=effective_fee,
                    user_monthly_spend_for_category=monthly_spend.get(top_cat, 0.0),
                    reward_rate=getattr(rc_for_top, "reward_rate", 0.0),
                    cap_type=getattr(rc_for_top, "cap_type", "none") if hasattr(rc_for_top, "cap_type") else "none",
                    monthly_cap_amount=getattr(rc_for_top, "monthly_cap_amount", None) if hasattr(rc_for_top, "monthly_cap_amount") else None,
                )

        card_result = {
            **card_meta,
            "eligible": True,
            "detailed_rules": detailed_rules,
            "monthly_breakdown": {k: round(v, 2) for k, v in monthly_category_rewards.items()},
            "breakdown": annual_category_rewards,
            "total_rewards": total_annual_rewards,
            "lounge_value": round(lounge_value, 2),
            "forex_cost": round(forex_cost, 2),
            "effective_fee": round(effective_fee, 2),
            "fee_waived": fee_waived,
            "net_value": net_value,
            "top_category": top_cat,
            "break_even_monthly_for_fee_recovery": round(break_even, 2) if isinstance(break_even, (int, float)) else break_even,
        }

        eligible_results.append(card_result)

    # --- Ranking & normalization ---
    if not eligible_results:
        return {
            "input": {"monthly_spend": monthly_spend, "monthly_foreign": monthly_foreign, "annual_income": annual_income},
            "ranked_results": [],
            "ineligible_results": ineligible_results,
            "message": "No eligible cards found given constraints.",
        }

    # normalize metrics, compute composite scores
    eligible_results = normalize_metrics_for_cards(eligible_results, include_net_value=True)
    eligible_results = compute_composite_scores(eligible_results, weights=weights or DEFAULT_WEIGHTS)

    # combine normalized net_value and composite score into final_score
    for c in eligible_results:
        normalized_net = c.get("normalized", {}).get("net_value", 0.0)
        composite = c.get("composite_score", 0.0)
        final_score = float(alpha) * normalized_net + (1.0 - float(alpha)) * composite
        c["final_score"] = round(final_score, 4)

    # ranking decision
    if rank_by == "net_value":
        eligible_results.sort(key=lambda x: (x["net_value"], x.get("composite_score", 0.0)), reverse=True)
        sorted_cards = []
        i = 0
        while i < len(eligible_results):
            group = [eligible_results[i]]
            j = i + 1
            while j < len(eligible_results) and abs(eligible_results[j]["net_value"] - eligible_results[i]["net_value"]) <= TIE_EPSILON:
                group.append(eligible_results[j])
                j += 1
            if len(group) > 1:
                group.sort(key=lambda x: (x.get("composite_score", 0.0), -x.get("effective_fee", 0.0), x.get("total_rewards", 0.0), x["name"]), reverse=True)
            sorted_cards.extend(group)
            i = j
    else:
        eligible_results.sort(key=lambda x: x.get("final_score", 0.0), reverse=True)
        sorted_cards = eligible_results

    for idx, card in enumerate(sorted_cards, start=1):
        card["rank"] = idx

    if include_ineligible:
        for r in ineligible_results:
            r["rank"] = None

    # sensitivity (optional)
    sensitivity = {}
    if run_sensitivity:
        for name, delta_map in SENSITIVITY_SCENARIOS.items():
            modified = user_input.copy()
            for k, factor in delta_map.items():
                if k in categories:
                    modified[k] = _safe_float(monthly_spend.get(k, 0.0)) * factor
                else:
                    modified[k] = _safe_float(user_input.get(k, 0.0)) * factor
            try:
                res = evaluate_cards(modified, weights=weights, alpha=alpha, lounge_value_per_visit=lounge_value_per_visit, rank_by=rank_by, include_ineligible=False, run_sensitivity=False)
                sensitivity[name] = [(r["name"], r["net_value"]) for r in res.get("ranked_results", [])[:5]]
            except Exception as e:
                logger.exception("sensitivity failed: %s", e)
                sensitivity[name] = {"error": str(e)}

    return {
        "input": {"monthly_spend": monthly_spend, "monthly_foreign": monthly_foreign, "annual_income": annual_income},
        "ranked_results": sorted_cards,
        "ineligible_results": ineligible_results,
        "sensitivity": sensitivity,
    }